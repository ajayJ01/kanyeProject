<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;
use App\Models\quoteUser;
class PostTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_example(): void
    {

        $quoteUser = quoteUser::factory()->create();

        $response = $this->post('store',[
            'name'=>$quoteUser->name,
            'email'=>$quoteUser->email,
            'password'=>$quoteUser->password,
        ]);  

        $response->assertStatus(302);
    }
}
